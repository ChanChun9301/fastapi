from .rignore import *

__doc__ = rignore.__doc__
if hasattr(rignore, "__all__"):
    __all__ = rignore.__all__